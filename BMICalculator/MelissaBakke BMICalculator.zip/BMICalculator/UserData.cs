﻿using System;
namespace BMICalculator
{
    static class UserData
    {
        public static double Height { get; set; }
        public static double Weight { get; set; }
        public static double BMI { get; set; }
    }
}
