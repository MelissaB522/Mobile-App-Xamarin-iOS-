using Foundation;
using System;
using UIKit;

namespace BMICalculator
{
    public partial class BMIViewController : UIViewController
    {
        public BMIViewController (IntPtr handle) : base (handle)
        {

        }

		public override void ViewDidLoad()
		{
            lblBMI.Text = Math.Round(UserData.BMI, 1).ToString();
		}


    }
}